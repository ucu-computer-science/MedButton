#ifndef C_LORA_TASK_H
#define C_LORA_TASK_H

void lora_send(void* param);

#endif //C_LORA_TASK_H